let treugolnik = "";
while (treugolnik.length <= 7) {
  console.log((treugolnik += "#"));
}
