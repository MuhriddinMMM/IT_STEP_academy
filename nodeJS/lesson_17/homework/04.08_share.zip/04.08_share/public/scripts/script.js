document.querySelector('.modal button').addEventListener('click', (e) => {
    e.target.parentElement.classList.toggle('hidden')
})