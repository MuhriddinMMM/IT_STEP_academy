const path = require("path");

const about = {
  about: (req, res) => {
    res.render("about");
  },
};
module.exports = about;