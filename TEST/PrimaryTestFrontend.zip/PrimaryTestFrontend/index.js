// a - b натуральные числа, включая ноль

function multi(a, b) {
  if (a > 0 && b > 0) {
    if (a == 1) return b;
    else if (b == 1) return a;
    else {
      return a + multi(a, b - 1);
    }
  } else return 0;
}
console.log(multi(3, 5));



// function sum(n) {
//   if (n == 1) {
//     return 1;
//   } else {
//     return sum(n - 1) + n;
//   }
// }
// console.log(sum(4));



// function sign(n) {
//   if (n > 0) return 1;
//   else return -1;
// }
// console.log(sign(-5));
